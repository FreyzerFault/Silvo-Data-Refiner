# Procesamiento de Datos de Collares

Esta herramienta ejecuta una pipeline de procesos de limpieza, unión y clasificación de datos de collares inteligentes.

Al final se obtiene un CSV con todo, y carpetas con los datos divididos por ID, por Mes, por hora...
Para poder luego usarlos de forma cómoda en QGIS o en cualquier tool, Unity,...
Están también divididos por categorías para poder agilizar los procesos con archivos de datos más compactos

## Datos

Los datasets deben estar en formato CSV.
Deben tener las siguientes columnas:

- device_id
- position_time
- time
- msg_type
- lat
- lon

Opcionales:

- mode
- collar_status
- fence_status

El programa ya se encarga de limpiarlos, ordenarlos y darles un formato consistente.

## Requisitos

- Python 3.x

## Instrucciones de Uso

1. Coloca los archivos de datos crudos de collares en formato `.csv` en la carpeta `data/in/`.
2. Puedes modificar el procesamiento en el archivo `config/settings.yaml`
3. Ejecuta el archivo `run.bat` para ejecutar toda la pipeline de procesamiento.
4. Los archivos `.csv` resultantes se generarán en la carpeta `data/out/`.

## Estructura del Proyecto

- `run.bat`: Archivo principal que ejecuta toda la pipeline de procesamiento.
- `data/`: Carpeta que contiene los datos de entrada y salida.
  - `data/in/`: Carpeta donde se deben colocar los archivos de datos de collares en formato `.csv`.
  - `data/out/`: Carpeta donde se generarán los archivos `.csv` resultantes después de ejecutar la pipeline.
- `config/`: Carpeta que contiene archivos de configuración.
  - `config/settings.yaml`: Archivo de configuración con los parámetros de la pipeline ETL.
- `src/`: Carpeta que contiene los scripts de procesamiento.
- `qgis scripts/`: Carpeta que contiene scripts que deben ejecutarse en la consola de QGIS.

## Conversión a SHP

Usa el script `csv_to_shp.py` para convertir los archivos `.csv` a archivos `.shp` usables en QGIS.
